from django.apps import AppConfig


class AgritradeConfig(AppConfig):
    name = 'agritrade'
